Lien vers le GitHub : https://github.com/Adri1-13/OnlyFilms

Lien vers Webetu : https://webetu.iutnc.univ-lorraine.fr/www/e67569u/onlyfilms/

Membres : Nicolas Claude, Pierre Logeart, Tristan Adam, Belaïb Nael, Adrien Tritarelli

Liste des fonctionnalités : voir le rapport pdf

Pour tester l'application :
mail user : test@mail.com
mail password : testtesttest